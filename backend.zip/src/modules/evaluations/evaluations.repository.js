import pool from "../../db/pool.js";

// ── Rubrics ───────────────────────────────────────────────────────────────────

export const getRubricsByEvent = async (eventId) => {
    const query = `
        SELECT
            id_rubric,
            id_event,
            area,
            name,
            description,
            weight,
            active
        FROM rubrics
        WHERE id_event = $1 AND active = true
        ORDER BY area, name
    `;
    const result = await pool.query(query, [eventId]);
    return result.rows;
};

export const getGradesByRubric = async (rubricId) => {
    const query = `
        SELECT id_grade, id_rubric, score, name, description
        FROM grades
        WHERE id_rubric = $1
        ORDER BY score DESC
    `;
    const result = await pool.query(query, [rubricId]);
    return result.rows;
};

// ── Evaluations ───────────────────────────────────────────────────────────────

export const getExistingEvaluation = async ({
                                                projectId,
                                                evaluatorUserId,
                                                evaluatedUserId,
                                                area,
                                            }) => {
    const query = `
        SELECT id_evaluation
        FROM evaluations
        WHERE project_id = $1
          AND evaluator_user_id = $2
          AND evaluated_user_id = $3
          AND area = $4::evaluation_area
    `;
    const result = await pool.query(query, [
        projectId,
        evaluatorUserId,
        evaluatedUserId,
        area,
    ]);
    return result.rows[0] || null;
};

export const upsertEvaluation = async ({
                                           projectId,
                                           eventId,
                                           evaluatorUserId,
                                           evaluatedUserId,
                                           area,
                                           feedback,
                                           gradeId,
                                       }) => {
    // Single upsert — works regardless of whether a unique constraint exists
    // on (project_id, evaluator_user_id, evaluated_user_id, area) or not.
    // If the constraint exists it updates; if not it tries to find & update manually.
    const query = `
        INSERT INTO evaluations
        (project_id, event_id, evaluator_user_id, evaluated_user_id, area, feedback, id_grade)
        VALUES ($1, $2, $3, $4, $5::evaluation_area, $6, $7)
        ON CONFLICT (project_id, evaluator_user_id, evaluated_user_id, area)
            DO UPDATE SET
                          feedback  = EXCLUDED.feedback,
                          id_grade  = EXCLUDED.id_grade,
                          event_id  = EXCLUDED.event_id
        RETURNING id_evaluation, project_id, event_id, evaluator_user_id, evaluated_user_id, area, feedback, id_grade, created_at
    `;
    const result = await pool.query(query, [
        projectId,
        eventId,
        evaluatorUserId,
        evaluatedUserId,
        area,
        feedback ?? null,
        gradeId,
    ]);
    return result.rows[0];
};

export const getEvaluationsByProject = async (projectId, evaluatorUserId) => {
    const query = `
        SELECT
            e.id_evaluation,
            e.project_id,
            e.event_id,
            e.evaluator_user_id,
            e.evaluated_user_id,
            e.area,
            e.feedback,
            e.created_at,
            e.id_grade,
            g.score,
            g.name AS grade_name,
            g.description AS grade_description,
            g.id_rubric,
            u.name AS evaluated_name,
            r.name AS rubric_name,
            r.weight
        FROM evaluations e
                 JOIN grades g ON e.id_grade = g.id_grade
                 JOIN rubrics r ON g.id_rubric = r.id_rubric
                 JOIN users u ON e.evaluated_user_id = u.id_user
        WHERE e.project_id = $1
          AND e.evaluator_user_id = $2
        ORDER BY e.evaluated_user_id, e.area
    `;
    const result = await pool.query(query, [projectId, evaluatorUserId]);
    return result.rows;
};

export const getRawEvaluationsForProject = async (projectId) => {
    const query = `
        SELECT
            e.evaluated_user_id,
            e.evaluator_user_id,
            e.area,
            g.id_rubric,
            r.weight,
            g.score,
            u.name AS evaluated_name
        FROM evaluations e
                 JOIN grades g ON e.id_grade = g.id_grade
                 JOIN rubrics r ON g.id_rubric = r.id_rubric
                 JOIN users u ON e.evaluated_user_id = u.id_user
        WHERE e.project_id = $1
        ORDER BY e.evaluated_user_id, e.area, g.id_rubric
    `;
    const result = await pool.query(query, [projectId]);
    return result.rows;
};

/**
 * Returns all active rubrics for the event linked to this project.
 */
export const getRubricsForProject = async (projectId) => {
    const query = `
        SELECT r.id_rubric, r.area, r.weight, r.name
        FROM rubrics r
                 JOIN projects p ON p.id_event = r.id_event
        WHERE p.id_project = $1 AND r.active = true
        ORDER BY r.area, r.id_rubric
    `;
    const result = await pool.query(query, [projectId]);
    return result.rows;
};

// ── individual_area_results upsert ───────────────────────────────────────────

export const upsertAreaResult = async ({
                                           projectId,
                                           userId,
                                           area,
                                           finalScore,
                                       }) => {
    const query = `
        INSERT INTO individual_area_results (project_id, user_id, area, final_score, calculated_at)
        VALUES ($1, $2, $3::evaluation_area, $4, now())
        ON CONFLICT (project_id, user_id, area)
            DO UPDATE SET final_score = EXCLUDED.final_score, calculated_at = now()
        RETURNING *
    `;
    const result = await pool.query(query, [projectId, userId, area, finalScore]);
    return result.rows[0];
};

// ── individual_project_results upsert ────────────────────────────────────────

export const upsertProjectResult = async ({
                                              projectId,
                                              userId,
                                              finalScore,
                                          }) => {
    const query = `
        INSERT INTO individual_project_results (project_id, user_id, final_score, calculated_at)
        VALUES ($1, $2, $3, now())
        ON CONFLICT (project_id, user_id)
            DO UPDATE SET final_score = EXCLUDED.final_score, calculated_at = now()
        RETURNING *
    `;
    const result = await pool.query(query, [projectId, userId, finalScore]);
    return result.rows[0];
};

// ── Read results ─────────────────────────────────────────────────────────────

export const getProjectResults = async (projectId) => {
    const query = `
        SELECT
            ipr.user_id,
            u.name             AS user_name,
            u.email,
            u.github_avatar_url,
            ipr.final_score,
            ipr.calculated_at,
            json_agg(
                    json_build_object(
                            'area',        iar.area,
                            'final_score', iar.final_score
                    ) ORDER BY iar.area
            ) AS area_scores
        FROM individual_project_results ipr
                 JOIN users u ON u.id_user = ipr.user_id
                 LEFT JOIN individual_area_results iar
                           ON iar.project_id = ipr.project_id AND iar.user_id = ipr.user_id
        WHERE ipr.project_id = $1
        GROUP BY
            ipr.user_id, u.name, u.email, u.github_avatar_url,
            ipr.final_score, ipr.calculated_at
        ORDER BY ipr.final_score DESC
    `;
    const result = await pool.query(query, [projectId]);
    return result.rows;
};

// ── Evaluator-count check (max 3 per area per project) ───────────────────────

/**
 * Returns the number of distinct evaluators who have already submitted
 * evaluations for (projectId, area). Used to enforce the 3-evaluator cap.
 */
export const countEvaluatorsForArea = async (projectId, area) => {
    const query = `
        SELECT COUNT(DISTINCT evaluator_user_id) AS total
        FROM evaluations
        WHERE project_id = $1
          AND area       = $2::evaluation_area
    `;
    const result = await pool.query(query, [projectId, area]);
    return parseInt(result.rows[0].total, 10);
};

/**
 * Returns true if evaluatorUserId has already submitted evaluations
 * for (projectId, area).
 */
export const hasEvaluatorSubmittedArea = async (
    projectId,
    evaluatorUserId,
    area,
) => {
    const query = `
        SELECT 1
        FROM evaluations
        WHERE project_id        = $1
          AND evaluator_user_id = $2
          AND area              = $3::evaluation_area
        LIMIT 1
    `;
    const result = await pool.query(query, [projectId, evaluatorUserId, area]);
    return result.rows.length > 0;
};

// ── Event evaluations_closed helpers ─────────────────────────────────────────

/**
 * Returns { evaluations_closed, id_event } for a given event.
 */
export const getEventEvalStatus = async (eventId) => {
    const result = await pool.query(
        `SELECT id_event, evaluations_closed FROM events WHERE id_event = $1`,
        [eventId],
    );
    return result.rows[0] || null;
};

/**
 * Sets evaluations_closed on an event.
 */
export const setEvaluationsClosed = async (eventId, closed) => {
    const result = await pool.query(
        `UPDATE events
         SET evaluations_closed = $2, updated_at = now()
         WHERE id_event = $1
         RETURNING id_event, evaluations_closed`,
        [eventId, closed],
    );
    return result.rows[0] || null;
};

/**
 * Checks whether every project in the event has at least 1 evaluation
 * for each required area (areas with active rubrics).
 *
 * Returns { canClose: boolean, missing: [{ projectId, projectName, missingAreas }] }
 */
export const getEventEvalCoverage = async (eventId) => {
    // Required areas for this event
    const areasRes = await pool.query(
        `SELECT DISTINCT area FROM rubrics WHERE id_event = $1 AND active = true`,
        [eventId],
    );
    const requiredAreas = areasRes.rows.map((r) => r.area);

    if (requiredAreas.length === 0) {
        return { canClose: false, missing: [] };
    }

    // All teams in the event (with or without submitted project)
    const teamsRes = await pool.query(
        `SELECT t.id_team, t.name AS team_name, p.id_project, p.name AS project_name
         FROM teams t
                  LEFT JOIN projects p ON p.team_id = t.id_team
         WHERE t.id_event = $1`,
        [eventId],
    );

    // If there are no teams at all, nothing to close
    if (teamsRes.rows.length === 0) {
        return { canClose: false, missing: [] };
    }

    const missing = [];

    for (const row of teamsRes.rows) {
        const projectId = row.id_project;

        // Team has no project at all — missing all areas
        if (!projectId) {
            missing.push({
                projectId: null,
                projectName: row.team_name,
                missingAreas: requiredAreas,
            });
            continue;
        }

        const coveredRes = await pool.query(
            `SELECT DISTINCT area FROM evaluations WHERE project_id = $1`,
            [projectId],
        );
        const covered = coveredRes.rows.map((r) => r.area);
        const missingAreas = requiredAreas.filter((a) => !covered.includes(a));

        if (missingAreas.length > 0) {
            missing.push({
                projectId,
                projectName: row.project_name ?? row.team_name,
                missingAreas,
            });
        }
    }

    return { canClose: missing.length === 0, missing };
};

// ── Event results ─────────────────────────────────────────────────────────────

export const getTeamEvalCounts = async (eventId) => {
    const result = await pool.query(
        `SELECT
             t.id_team,
             t.name AS team_name,
             area_counts.area,
             COALESCE(area_counts.evaluator_count, 0) AS evaluator_count
         FROM teams t
                  LEFT JOIN projects p ON p.team_id = t.id_team
                  LEFT JOIN (
             SELECT
                 e.project_id,
                 e.area,
                 COUNT(DISTINCT e.evaluator_user_id) AS evaluator_count
             FROM evaluations e
             GROUP BY e.project_id, e.area
         ) area_counts ON area_counts.project_id = p.id_project
         WHERE t.id_event = $1
         ORDER BY t.name, area_counts.area`,
        [eventId],
    );
    return result.rows;
};

export const getEventResults = async (eventId) => {
    const query = `
        SELECT
            ipr.project_id,
            p.name             AS project_name,
            t.name             AS team_name,
            ipr.user_id,
            u.name             AS user_name,
            u.email,
            u.github_avatar_url,
            ipr.final_score,
            ipr.calculated_at,
            json_agg(
                    json_build_object(
                            'area',        iar.area,
                            'final_score', iar.final_score
                    ) ORDER BY iar.area
            ) AS area_scores
        FROM individual_project_results ipr
                 JOIN users u ON u.id_user = ipr.user_id
                 JOIN projects p ON p.id_project = ipr.project_id
                 JOIN teams t ON t.id_team = p.team_id
                 LEFT JOIN individual_area_results iar
                           ON iar.project_id = ipr.project_id AND iar.user_id = ipr.user_id
        WHERE p.id_event = $1
        GROUP BY
            ipr.project_id, p.name, t.name,
            ipr.user_id, u.name, u.email, u.github_avatar_url,
            ipr.final_score, ipr.calculated_at
        ORDER BY ipr.final_score DESC
    `;
    const result = await pool.query(query, [eventId]);
    return result.rows;
};

export default {
    getRubricsByEvent,
    getGradesByRubric,
    getExistingEvaluation,
    upsertEvaluation,
    getEvaluationsByProject,
    getRawEvaluationsForProject,
    getRubricsForProject,
    upsertAreaResult,
    upsertProjectResult,
    getProjectResults,
    getEventResults,
    countEvaluatorsForArea,
    hasEvaluatorSubmittedArea,
    getEventEvalStatus,
    setEvaluationsClosed,
    getEventEvalCoverage,
    getTeamEvalCounts,
};
